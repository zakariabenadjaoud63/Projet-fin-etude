<?php $activePage = 'home'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MécaSpeed — Mécanique rapide en ligne</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/mecaspeed-style.css">
</head>
<body>

<header class="site-header">
  <div class="container nav-inner">
    <a class="nav-logo" href="index_adapte.php">Méca<span>Speed</span></a>

    <button class="menu-toggle" type="button" aria-label="Ouvrir le menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

    <nav class="nav-links" aria-label="Navigation principale">
      <a href="#accueil" class="is-active">Accueil</a>
      <a href="boutique.php">Boutique</a>
      <a href="rendezvous.php">Prendre RDV</a>
      <a href="Login.html">Se connecter</a>
      <a href="inscription.html" class="nav-cta">S'inscrire</a>
    </nav>
  </div>
</header>

<main>
  <!-- HERO -->
  <section id="accueil" class="hero">
    <div class="hero-texture"></div>
    <div class="container hero-grid">
      <div class="hero-copy">
        <span class="eyebrow">Garage connecté — service rapide</span>
        <h1>Votre véhicule<br>suivi avec<br><em>confiance.</em></h1>
        <p class="hero-lead">
          MécaSpeed simplifie l'entretien automobile : prise de rendez-vous, catalogue de pièces,
          suivi des réparations et espace client moderne.
        </p>

        <div class="hero-actions">
          <a class="btn btn-primary" href="rendezvous.php">Prendre un RDV</a>
          <a class="btn btn-light" href="#actions-client">Voir les services</a>
        </div>

        <div class="trust-pills">
          <span>Disponible 24h/24</span>
          <span>Diagnostic clair</span>
          <span>Suivi en ligne</span>
          <span>Panier pièces</span>
        </div>
      </div>

      <div class="hero-panel-wrap">
        <div class="hero-panel">
          <div class="panel-top">
            <span class="status-dot">Plateforme active</span>
            <span>2025 / 2026</span>
          </div>

          <p class="panel-title">Parcours client MécaSpeed</p>

          <div class="steps">
            <div class="step-row"><span>01</span><strong>Choisir un service</strong></div>
            <div class="step-row"><span>02</span><strong>Réserver un créneau</strong></div>
            <div class="step-row"><span>03</span><strong>Suivre la réparation</strong></div>
            <div class="step-row"><span>04</span><strong>Récupérer le véhicule</strong></div>
          </div>

          <div class="panel-contact">
            <div>
              <small>Projet</small>
              <strong>Mécanique rapide</strong>
            </div>
            <div>
              <small>Interface</small>
              <strong>Web client</strong>
            </div>
          </div>
        </div>

        <div class="floating-card">
          <div class="floating-icon">🔧</div>
          <div>
            <strong>Réparation suivie</strong>
            <p>Statut : en cours</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- STATS -->
  <section class="stats-band" aria-label="Chiffres clés">
    <div class="container stats-grid">
      <article>
        <strong>24<span>h</span></strong>
        <p>Accès aux services en ligne</p>
      </article>
      <article>
        <strong>6<span>+</span></strong>
        <p>Interventions rapides principales</p>
      </article>
      <article>
        <strong>3</strong>
        <p>Services client essentiels</p>
      </article>
      <article>
        <strong>100<span>%</span></strong>
        <p>Expérience digitalisée</p>
      </article>
    </div>
  </section>

  <!-- SERVICES -->
  <section id="services" class="section services">
    <div class="container">
      <div class="section-head">
        <div>
          <span class="eyebrow">Nos interventions rapides</span>
          <h2>Entretien automobile simple et structuré.</h2>
        </div>
        <a class="text-link" href="rendezvous.php">Réserver maintenant</a>
      </div>

      <div class="service-grid">
        <article class="service-card">
          <span class="badge">Entretien</span>
          <h3>Vidange et huile</h3>
          <p>Vidange moteur, contrôle du niveau et choix d'huile adapté au véhicule.</p>
        </article>

        <article class="service-card">
          <span class="badge">Filtres</span>
          <h3>Remplacement filtres</h3>
          <p>Filtres à air, huile et carburant pour améliorer la fiabilité du moteur.</p>
        </article>

        <article class="service-card">
          <span class="badge">Sécurité</span>
          <h3>Plaquettes de freins</h3>
          <p>Contrôle et remplacement des plaquettes pour une conduite plus sûre.</p>
        </article>

        <article class="service-card">
          <span class="badge">Pneus</span>
          <h3>Remplacement pneus</h3>
          <p>Montage, vérification et conseils pour garder une bonne adhérence.</p>
        </article>

        <article class="service-card">
          <span class="badge">Énergie</span>
          <h3>Batterie</h3>
          <p>Contrôle de charge, remplacement et diagnostic de démarrage.</p>
        </article>

        <article class="service-card">
          <span class="badge">Contrôle</span>
          <h3>Vérifications générales</h3>
          <p>Niveaux, éclairage, état visuel et points de contrôle essentiels.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- ACTIONS CLIENT -->
  <section id="actions-client" class="section actions-client">
    <div class="container actions-grid">
      <div class="actions-copy">
        <span class="eyebrow">Vos services en ligne</span>
        <h2>Une interface pensée pour le client.</h2>
        <p>
          Les fonctionnalités principales de MécaSpeed permettent de gérer les rendez-vous,
          consulter le catalogue et suivre les réparations en temps réel.
        </p>
      </div>

      <div class="action-stack">
        <article class="action-card">
          <div class="action-icon">📅</div>
          <div>
            <h3>Gestion des rendez-vous</h3>
            <p>Réservez, modifiez ou annulez votre créneau d'intervention directement en ligne.</p>
            <a class="btn btn-primary" href="rendezvous.php">Prendre un RDV</a>
          </div>
        </article>

        <article class="action-card">
          <div class="action-icon">🛒</div>
          <div>
            <h3>Catalogue et pièces</h3>
            <p>Parcourez les produits, ajoutez au panier et préparez votre commande facilement.</p>
            <a class="btn btn-outline js-add-cart" href="boutique.php">Accéder à la boutique</a>
          </div>
        </article>

        <article class="action-card">
          <div class="action-icon">🚗</div>
          <div>
            <h3>Suivi en temps réel</h3>
            <p>Recherchez votre véhicule via son immatriculation et consultez la progression des travaux.</p>
            <button class="btn btn-outline js-track-car" type="button">Suivre mes réparations</button>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="final-cta">
    <div class="container cta-panel">
      <div>
        <span class="eyebrow">Passez à l'action</span>
        <h2>Besoin d'un entretien ou d'un suivi véhicule ?</h2>
        <p>MécaSpeed centralise vos demandes pour réduire l'attente et améliorer la communication avec le garage.</p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary" href="rendezvous.php">Prendre RDV</a>
        <a class="btn btn-light" href="boutique.php">Voir la boutique</a>
      </div>
    </div>
  </section>
</main>

<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <span class="footer-logo">Méca<span>Speed</span></span>
      <p>Solution moderne et innovante pour l'entretien rapide de votre véhicule.</p>
    </div>

    <div>
      <h4>Navigation</h4>
      <a href="#accueil">Accueil</a>
      <a href="#services">Services</a>
      <a href="#actions-client">Espace client</a>
    </div>

    <div>
      <h4>Plateforme</h4>
      <a href="boutique.php">Boutique</a>
      <a href="rendezvous.php">Rendez-vous</a>
      <a href="Login.html">Connexion</a>
    </div>

    <div>
      <h4>Projet</h4>
      <p>Kherchaoui, Benadjaoud, Kahlouche.</p>
      <p>Université Mouloud Mammeri de Tizi-Ouzou.</p>
    </div>
  </div>

  <div class="container footer-bottom">
    <span>© 2025/2026 MécaSpeed. Tous droits réservés.</span>
    <span>Faculté du Génie Électrique et d'Informatique.</span>
  </div>
</footer>

<script src="assets/js/mecaspeed-app.js"></script>
</body>
</html>
