/* ==========================================================================
   MécaSpeed — Interactions adaptées
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  // Menu mobile
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("is-open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  // Navigation fluide pour les ancres internes
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const target = document.querySelector(link.getAttribute("href"));

      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });

        if (navLinks) {
          navLinks.classList.remove("is-open");
        }

        if (menuToggle) {
          menuToggle.setAttribute("aria-expanded", "false");
        }
      }
    });
  });

  // Compteur panier dans la navigation
  if (navLinks && !document.querySelector(".cart-pill")) {
    const cart = document.createElement("a");
    cart.href = "boutique.php";
    cart.className = "cart-pill";
    cart.innerHTML = '🛒 Panier <span id="compteur-panier">0</span>';
    navLinks.appendChild(cart);
  }

  // Simulation ajout panier depuis la carte boutique
  const addCartButton = document.querySelector(".js-add-cart");
  let cartQuantity = 0;

  if (addCartButton) {
    addCartButton.addEventListener("click", (event) => {
      event.preventDefault();
      cartQuantity += 1;

      const counter = document.getElementById("compteur-panier");
      if (counter) {
        counter.textContent = cartQuantity;
        counter.style.transform = "scale(1.25)";
        setTimeout(() => {
          counter.style.transform = "scale(1)";
        }, 140);
      }

      window.alert("Produit simulé ajouté au panier !\nModèle conceptuel : entité Panier mise à jour.");
    });
  }

  // Suivi véhicule
  const trackButton = document.querySelector(".js-track-car");

  if (trackButton) {
    trackButton.addEventListener("click", () => {
      const immatriculation = window.prompt("Veuillez saisir votre plaque d'immatriculation (Ex : 12345-120-15) :");

      if (immatriculation === null) {
        return;
      }

      if (immatriculation.trim() === "") {
        window.alert("Saisie invalide. Veuillez entrer un numéro d'immatriculation.");
        return;
      }

      window.alert(
        `Recherche du véhicule [${immatriculation.toUpperCase()}]...\n\n` +
        "Statut : En cours de réparation.\n" +
        'Note du mécanicien : "Changement des plaquettes de frein terminé. En attente du contrôle des niveaux."'
      );
    });
  }

  // Animation d'apparition progressive
  const animatedElements = document.querySelectorAll(".service-card, .action-card, .stats-grid article");

  animatedElements.forEach((element, index) => {
    element.classList.add("reveal");
    element.style.transitionDelay = `${Math.min(index * 70, 420)}ms`;
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  animatedElements.forEach((element) => observer.observe(element));
});
